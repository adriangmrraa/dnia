# Estado del proyecto — fuente compartida resumida

- Estado: STARTER SIN INICIAR (no significa gate ni instalación completados)
- Participante/equipo: POR DEFINIR (evitar PII)
- Idea/problema: POR DEFINIR
- Fase SDD actual: INIT PENDIENTE
- Research Gate: NO INICIADO / NO APROBADO
- Entorno real: NO VERIFICADO
- Engram: NO VERIFICADO
- Matt Pocock Skills: NO VERIFICADO
- Colosseum Copilot: NO VERIFICADO
- Solana Dev Skill: NO VERIFICADO
- Superteam Rules: NO DESCARGADAS
- Change activo: NINGUNO (crear `sdd/changes/<slug>/` solo tras Gate)
- Última decisión humana: NINGUNA
- Próxima acción: abrir `PROMPT_DE_INICIO.md` en el agente con esta carpeta.
- Bloqueos: POR RELEVAR
- Última actualización: plantilla (01/10/2026)

Al cerrar cada sesión: registrar log y resultado real; NO inferir cumplimiento por existencia de archivos.
