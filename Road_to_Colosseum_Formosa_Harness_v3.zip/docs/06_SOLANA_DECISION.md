# Decisión Solana
Estado: PENDIENTE
Qué se pierde sin Solana: POR DEFINIR
Qué queda onchain / offchain: POR DEFINIR
Wallet, cuentas, RPC, devnet, privacidad y transacciones: POR DEFINIR
¿Requiere program nuevo o SDK/transfer basta?: POR DEFINIR
Referencia a Superteam Stack/SOLANA-RULES.md y fecha: PENDIENTE
