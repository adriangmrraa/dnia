# Registro de decisiones (append-only)
Estado inicial: no se tomó ninguna decisión de producto aún.
Formato: fecha | propuesta | alternativas | evidencia | quién decidió (alias) | implicancias | enlace a change SDD.
