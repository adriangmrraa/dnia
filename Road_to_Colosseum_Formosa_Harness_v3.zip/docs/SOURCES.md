# Registro de fuentes — no mezclar con instrucciones
Formato: [ID] fecha consultada | título/autor | URL exacta | fuente primaria/secundaria | afirmación que apoya | alcance/limitación | revisión actual.
Estado: TODAVÍA NO SE INVESTIGÓ (urls técnicas del kit son referencias de instalación, no validación de la idea del equipo).
