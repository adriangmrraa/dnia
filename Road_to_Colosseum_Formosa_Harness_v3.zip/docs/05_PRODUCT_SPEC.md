# Baseline de producto / negocio (no reemplaza SDD por cambio)
Estado: PENDIENTE — se elabora luego del Research Gate
ICP y contexto: PENDIENTE
Usuario/pagador/decisor: PENDIENTE
Propuesta de valor y alternativa actual: PENDIENTE
Recorrido central: PENDIENTE
MUST / SHOULD / LATER / OUT: PENDIENTE
Métrica/hipótesis y modo de prueba: PENDIENTE
Cambios SDD activos: NINGUNO
