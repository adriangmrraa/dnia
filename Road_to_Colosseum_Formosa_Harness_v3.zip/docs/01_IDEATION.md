# Ideación / hipótesis de problema
Estado: PENDIENTE
Áreas conocidas por participantes: POR PREGUNTAR
Problemas observables / usuario / workaround / hipótesis y evidencia: POR INVESTIGAR
Opciones descartadas y por qué: NINGUNA
Problema elegido PARA RESEARCH (no producto aprobado): POR DECIDIR
