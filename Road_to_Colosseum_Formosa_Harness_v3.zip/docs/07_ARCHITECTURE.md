# Arquitectura elegida
Estado: PENDIENTE
Diagrama simple de componentes, datos y trust boundaries: PENDIENTE
Stack probado (no fantasía): PENDIENTE
Seguridad, dependencia externa, plan de pruebas, deployment opcional: PENDIENTE
Link al change SDD activo: NINGUNO
